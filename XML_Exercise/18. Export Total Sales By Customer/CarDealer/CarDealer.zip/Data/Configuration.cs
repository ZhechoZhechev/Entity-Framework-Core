﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=CarDealer;User Id=sa;Password=8201291108;Trusted_Connection=False;MultipleActiveResultSets=true; TrustServerCertificate=true;";
    }

}
